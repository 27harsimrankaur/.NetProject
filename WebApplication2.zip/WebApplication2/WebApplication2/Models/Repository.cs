﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public static class Repository
    {
        public static List<Registration> registrations = new List<Registration>();
        public static IEnumerable<Registration> Registrations
        {
            get
            {
                return registrations;
            }
        }
        public static void AddRegistration(Registration registration)
        {
            registrations.Add(registration);
        }
    }
}
